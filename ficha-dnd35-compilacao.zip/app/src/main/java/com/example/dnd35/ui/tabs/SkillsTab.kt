package com.example.dnd35.ui.tabs

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.dnd35.model.CalculatedCharacterStats
import com.example.dnd35.model.CharacterEntity
import com.example.dnd35.model.ComputedSkill
import com.example.dnd35.ui.dialogs.DiceRollDialog
import com.example.dnd35.viewmodel.CharacterViewModel
import com.example.ui.theme.DndCrimson
import com.example.ui.theme.DndGold
import com.example.ui.theme.DndHpGreen

@Composable
fun SkillsTab(
    viewModel: CharacterViewModel,
    stats: CalculatedCharacterStats,
    character: CharacterEntity
) {
    var searchQuery by remember { mutableStateOf("") }
    var filterType by remember { mutableIntStateOf(0) } // 0: Todas, 1: De Classe, 2: Com Graduação
    var editingSkill by remember { mutableStateOf<ComputedSkill?>(null) }
    var diceRollTarget by remember { mutableStateOf<Pair<String, Int>?>(null) }

    val maxClassRank = character.level + 3
    val maxCrossRank = maxClassRank / 2.0f
    val totalRanksSpent = stats.computedSkills.sumOf { it.ranks.toDouble() }

    val filteredSkills = stats.computedSkills.filter {
        val matchesQuery = it.skill.name.contains(searchQuery, ignoreCase = true) ||
                it.skill.keyAbility.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (filterType) {
            1 -> it.isClassSkill
            2 -> it.ranks > 0f
            else -> true
        }
        matchesQuery && matchesFilter
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .testTag("skills_tab")
    ) {
        // Banner de Graduação Máxima e Gastos
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Graduação Máxima: $maxClassRank (Classe) / $maxCrossRank (Entre-classe)",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            "Graduações totais investidas: ${String.format("%.1f", totalRanksSpent)} pts",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                    if (stats.armorCheckPenalty < 0) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DndCrimson),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                "Pen: ${stats.armorCheckPenalty}",
                                color = androidx.compose.ui.graphics.Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Barra de Busca
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Buscar perícia (ex: Observar, Furtividade)...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Filtros Chips
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = filterType == 0,
                    onClick = { filterType = 0 },
                    label = { Text("Todas (${stats.computedSkills.size})") }
                )
                FilterChip(
                    selected = filterType == 1,
                    onClick = { filterType = 1 },
                    label = { Text("★ De Classe") }
                )
                FilterChip(
                    selected = filterType == 2,
                    onClick = { filterType = 2 },
                    label = { Text("Treinadas (>0)") }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Lista de Perícias
        items(filteredSkills) { item ->
            SkillItemRow(
                computed = item,
                onAddRank = {
                    val step = if (item.isClassSkill) 1.0f else 0.5f
                    viewModel.updateSkill(item.skill.name, item.ranks + step, item.miscBonus, item.isClassSkill)
                },
                onSubRank = {
                    val step = if (item.isClassSkill) 1.0f else 0.5f
                    viewModel.updateSkill(item.skill.name, (item.ranks - step).coerceAtLeast(0f), item.miscBonus, item.isClassSkill)
                },
                onEdit = { editingSkill = item },
                onRoll = {
                    diceRollTarget = Pair(item.skill.name, item.totalBonus)
                }
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal de Edição Detalhada da Perícia
    editingSkill?.let { comp ->
        var rankInput by remember { mutableStateOf("${comp.ranks}") }
        var miscInput by remember { mutableStateOf("${comp.miscBonus}") }
        var isClass by remember { mutableStateOf(comp.isClassSkill) }

        AlertDialog(
            onDismissRequest = { editingSkill = null },
            title = { Text("Ajustar Perícia: ${comp.skill.name}", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Atributo Chave: ${comp.skill.keyAbility} (Mod: ${if (comp.keyAbilityMod >= 0) "+${comp.keyAbilityMod}" else "${comp.keyAbilityMod}"})",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (comp.armorPenaltyApplied != 0) {
                        Text(
                            "Penalidade de Armadura aplicada: ${comp.armorPenaltyApplied}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DndCrimson
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = rankInput,
                        onValueChange = { rankInput = it },
                        label = { Text("Pontos de Graduação") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = miscInput,
                        onValueChange = { miscInput = it },
                        label = { Text("Bônus Diversos / Talentos (ex: +3 Foco em Perícia)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isClass, onCheckedChange = { isClass = it })
                        Text("Perícia de Classe para ${character.characterClass}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val r = rankInput.toFloatOrNull()?.coerceAtLeast(0f) ?: comp.ranks
                    val m = miscInput.toIntOrNull() ?: comp.miscBonus
                    viewModel.updateSkill(comp.skill.name, r, m, isClass)
                    editingSkill = null
                }) {
                    Text("Salvar")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { editingSkill = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Modal de Rolagem de d20 da Perícia
    diceRollTarget?.let { (name, bonus) ->
        DiceRollDialog(
            actionTitle = "Teste de $name",
            bonus = bonus,
            damageNotation = "",
            onDismiss = { diceRollTarget = null }
        )
    }
}

@Composable
fun SkillItemRow(
    computed: ComputedSkill,
    onAddRank: () -> Unit,
    onSubRank: () -> Unit,
    onEdit: () -> Unit,
    onRoll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (computed.ranks > 0) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Estrela de Classe
            if (computed.isClassSkill) {
                Icon(
                    Icons.Default.Star,
                    contentDescription = "Perícia de Classe",
                    tint = DndGold,
                    modifier = Modifier
                        .size(16.dp)
                        .padding(end = 4.dp)
                )
            } else {
                Spacer(modifier = Modifier.width(16.dp))
            }

            // Nome e Detalhes
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable(onClick = onEdit)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = computed.skill.name,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (computed.ranks > 0) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "[${computed.skill.keyAbility}]",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
                val formula = "Grad: ${computed.ranks} + Mod: ${computed.keyAbilityMod}" +
                        (if (computed.miscBonus != 0) " + Div: ${computed.miscBonus}" else "") +
                        (if (computed.armorPenaltyApplied != 0) " Pen: ${computed.armorPenaltyApplied}" else "")
                Text(
                    text = formula,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Bônus Total em destaque
            val totalStr = if (computed.totalBonus >= 0) "+${computed.totalBonus}" else "${computed.totalBonus}"
            Text(
                text = totalStr,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = if (computed.totalBonus >= 0) DndHpGreen else DndCrimson,
                modifier = Modifier
                    .clickable(onClick = onRoll)
                    .padding(horizontal = 8.dp)
            )

            // Botão de Rolar Dado d20
            IconButton(onClick = onRoll, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Casino, contentDescription = "Rolar", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            }

            // Botões de Graduação (+ e -)
            IconButton(
                onClick = onSubRank,
                enabled = computed.ranks > 0,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Diminuir Graduação", modifier = Modifier.size(16.dp))
            }

            IconButton(
                onClick = onAddRank,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Aumentar Graduação", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
            }
        }
    }
}
